package com.example.beautyparlour;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.MenuView;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends AppCompatActivity implements View.OnClickListener {


    private CardView Haircut,Skintreatment,Makeup,Handsandfeet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_home);

        Haircut = findViewById(R.id.haircut);
        Skintreatment = findViewById(R.id.sknt);
        Makeup = findViewById(R.id.mkup);
        Handsandfeet = findViewById(R.id.hanf);

        Haircut.setOnClickListener(this);
        Skintreatment.setOnClickListener(this);
        Makeup.setOnClickListener(this);
        Handsandfeet.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        Intent i;

        switch (v.getId()){
            case R.id.haircut : i = new Intent(this,Hairtype.class);startActivity(i);break;
            case R.id.sknt : i = new Intent(this,Skinbasics.class);startActivity(i);break;
            case R.id.mkup : i = new Intent(this,Makeuptypes.class);startActivity(i);break;
            case R.id.hanf : i = new Intent(this,Handandfeettype.class);startActivity(i);break;
            default:break;
        }
    }
}